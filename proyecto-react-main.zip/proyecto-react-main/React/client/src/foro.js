
import React from 'react';



const Foro = () => {
    return(

        <div>   
            
        </div>

        )
}
export default Foro;